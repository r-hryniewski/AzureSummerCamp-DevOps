# BlazorApp
Simple blazor app to exercise basic CI/CD on workshops
